<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Anggota</h1> 
        <a target="_blank" href="pages/cetak.php"class="btn btn-primary btn-circle btn-sm "><i class="fas fa-print"></i> </a> 
        <br> 
        
        <a href="index.php?p=anggota-input" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Anggota</a>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- Area Selamat datang -->
        <div class="col-xl-12 ">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Anggota</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Id Anggota</th>
                                    <th>Nama</th>
                                    <th>foto</th>
                                    <th>Jenis kelamin</th>
                                    <th>Alamat</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
		$sql="SELECT * FROM tbanggota ORDER BY idanggota DESC";
		$q_tampil_anggota = mysqli_query($conn, $sql);
		
		$nomor=1;
		while($r_tampil_anggota=mysqli_fetch_array($q_tampil_anggota)){

            
			if(empty($r_tampil_anggota['foto'])or($r_tampil_anggota['foto']=='-'))
            $foto = "./undraw_person.svg";
        else
            $foto = $r_tampil_anggota['foto'];
		?>
                                <tr>
                                    <td><?php echo $nomor++; ?></td>
                                    <td><?php echo $r_tampil_anggota['idanggota']; ?></td>
                                    <td><?php echo $r_tampil_anggota['nama']; ?></td>
                                    <td><img src="img/<?php echo $foto; ?>" width=60px height=60px></td>
                                    <td><?php echo $r_tampil_anggota['jeniskelamin']; ?></td>
                                    <td><?php echo $r_tampil_anggota['alamat']; ?></td>
                                    <td>
            <a target="_blank" href="pages/cetak_kartu.php?id=<?php echo $r_tampil_anggota['idanggota'];?>"class="btn btn-primary btn-circle btn-sm "><i class="fas fa-print"></i> </a> 
                                 
            <a href="index.php?p=anggota-edit&id=<?php echo $r_tampil_anggota['idanggota'];?>" class="btn btn-success btn-circle btn-sm "><i class="fas fa-pen"></i></a>
            <a href="proses/anggota-hapus.php?id=<?php echo $r_tampil_anggota['idanggota']; ?>" onclick="return_confirmation('Apakah Anda Yakin Akan Menghapus Data Ini?')" class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash"></i></a>
            
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->