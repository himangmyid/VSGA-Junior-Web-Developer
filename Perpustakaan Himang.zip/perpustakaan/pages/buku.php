<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Buku</h1> 
    <br>
    <a href="#" class="btn btn-sm btn-primary shadow-sm">
    <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Buku</a>
    </div>
    <!-- Content Row -->
    <div class="row">
    <!-- Area Selamat datang -->
    <div class="col-xl-12 ">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Buku</h6></div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Id Buku</th>
                                    <th>Judul Buku</th>
                                    <th>Kategori</th>
                                    <th>Pengarang</th>
                                    <th>Penerbit</th>  
                                    <th>Status</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
		                            $sql="SELECT * FROM tbbuku ORDER BY idbuku DESC";
	                            	$q_tampil_buku = mysqli_query($conn, $sql);
		                            $nomor=1;
		                            while($r_tampil_buku=mysqli_fetch_array($q_tampil_buku)){ ?>
                                <tr>
                                    <td><?php echo $nomor++; ?></td>
                                    <td><?php echo $r_tampil_buku['idbuku']; ?></td>
                                    <td><?php echo $r_tampil_buku['judulbuku']; ?></td>
                                    <td><?php echo $r_tampil_buku['kategori']; ?></td>
                                    <td><?php echo $r_tampil_buku['pengarang']; ?></td>
                                    <td><?php echo $r_tampil_buku['penerbit']; ?></td>
                                    <td><?php echo $r_tampil_buku['status']; ?></td>
                                    <td><a href="#" class="btn btn-success btn-circle btn-sm "><i class="fas fa-pen"></i></a>
                                    <a href="#" class="btn btn-danger btn-circle btn-sm"><i class="fas fa-trash"></i></a>
                                    
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->