<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Anggota</h1>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- Area Selamat datang -->
        <div class="col-xl-12 ">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Anggota</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <form action="proses/anggota-input-proses.php" method="post">
                        <div class="row mb-3">
                            <label for="formFile" class="col-sm-2 col-form-label">Foto</label>
                            <div class="col-sm-10"><input class="form-control form-control-file" type="file" name="foto" id="formFileMultiple" multiple></div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Id Anggota</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputEmail3" name="id_anggota">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputEmail3" name="nama">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-form-label col-sm-2 pt-0">Jenis Kelamin</label>
                            <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio"  name="jenis_kelamin" id="exampleRadios1" value="Pria" checked>
  <label class="form-check-label" for="exampleRadios1">Pria</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="jenis_kelamin" id="exampleRadios2" value="Wanita">
  <label class="form-check-label" for="exampleRadios2">
    Wanita
  </label>
</div>
  
 
                           
                        </div>


                        <div class="row mb-3">
                            <label for="inputAddress" class="col-sm-2 col-form-label">Alamat</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputAddress" name="alamat">
                            </div>
                        </div>
                        <button type="reset" class="btn btn-danger">Batal</button>
                        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->