<?php
include'../db.php';
$id_anggota=$_GET['id'];

mysqli_query($conn,
	"DELETE FROM tbanggota
	WHERE idanggota='$id_anggota'"
);
header("location:../index.php?p=anggota");
?>