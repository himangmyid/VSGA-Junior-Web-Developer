<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$db_name = 'dbpus';

$conn = mysqli_connect($hostname, $username, $password, $db_name) or die ('Gagal terhubung ke Database')


?>